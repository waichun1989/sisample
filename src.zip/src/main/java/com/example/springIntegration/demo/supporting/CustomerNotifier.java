package com.example.springIntegration.demo.supporting;

public class CustomerNotifier {
    public static void sendWelcomeEmail(Customer customer) {
        System.out.println("Sending welcome email to " + customer.email);
    }
}
