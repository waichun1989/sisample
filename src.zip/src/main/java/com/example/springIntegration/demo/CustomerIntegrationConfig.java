//package com.example.springIntegration.demo;
//
//import com.example.springIntegration.demo.supporting.Customer;
//import org.springframework.context.annotation.Bean;
//import org.springframework.context.annotation.Configuration;
//import org.springframework.integration.channel.DirectChannel;
//import org.springframework.integration.config.EnableIntegration;
//import org.springframework.integration.core.GenericHandler;
//import org.springframework.integration.dsl.IntegrationFlow;
//import org.springframework.messaging.MessageChannel;
//import org.springframework.retry.annotation.Retryable;
//
//@Configuration
//@EnableIntegration
//public class CustomerIntegrationConfig {
//
//    @Bean
//    public MessageChannel customerInputChannel() {
//        return new DirectChannel();
//    }
//
//    @Bean
//    public MessageChannel auditChannel() {
//        return new DirectChannel();
//    }
//
//    @Bean
//    public IntegrationFlow auditLogger() {
//        return IntegrationFlow.from("auditChannel")
//                .handle(m -> System.out.println("[AUDIT] " + m.getPayload()))
//                .get();
//    }
//
//    @Bean
//    public IntegrationFlow customerOnboardingFlow() {
//        return IntegrationFlow.from("customerInputChannel")
//                .wireTap("auditChannel") // observability
//                .handle((GenericHandler<Customer>) (customer, headers) -> {
//                    validate(customer);
//                    return customer;
//                }).handle((GenericHandler<Customer>) (customer, headers) -> {
//                    saveWithRetry(customer);
//                    return customer;
//                })
//                .route(Customer.class, Customer::isVip, mapping -> mapping
//                        .subFlowMapping(true, sf -> sf
//                                .handle((GenericHandler<Customer>) (customer, headers) -> {
//                                    sendEmailWithRetry(customer);
//                                    return customer;
//                                })
//                                .handle((GenericHandler<Customer>) (customer, headers) -> {
//                                    sendSmsWithRetry(customer);
//                                    return customer;
//                                }))
//                        .subFlowMapping(false, sf -> sf
//                                .handle((GenericHandler<Customer>) (customer, headers) -> {
//                                    sendEmailWithRetry(customer);
//                                    return customer;
//                                })
//                        ))
//                .handle((GenericHandler<Customer>) (customer, headers) -> {
//                    sendToKafka(customer);
//                    return customer;
//                })
//                .handle((GenericHandler<Customer>) (customer, headers) -> {
//                    finalLog(customer);
//                    return null;
//                }).get();
//    }
//
//    public void validate(Customer customer) {
//        if (customer.name == null || customer.email == null) {
//            throw new IllegalArgumentException("Invalid customer");
//        }
//    }
//
//    @Retryable(maxAttempts = 3)
//    public void saveWithRetry(Customer customer) {
//        System.out.println("Attempt DB Save...");
//        simulateUnstableService("DB Save", 0.2); // simulate 20% fail
//        System.out.println("DB Saved.");
//    }
//
//    @Retryable(maxAttempts = 3)
//    public void sendEmailWithRetry(Customer customer) {
//        System.out.println("Attempt Email Send...");
//        simulateUnstableService("Email Send", 0.3);
//        System.out.println("Email Sent.");
//    }
//
//    @Retryable(maxAttempts = 3)
//    public void sendSmsWithRetry(Customer customer) {
//        System.out.println("Attempt SMS Send...");
//        simulateUnstableService("SMS Send", 0.3);
//        System.out.println("SMS Sent.");
//    }
//
//    public void sendToKafka(Customer customer) {
//        System.out.println("Mock Kafka: " + customer);
//    }
//
//    public void finalLog(Customer customer) {
//        System.out.println("Onboarding completed for: " + customer);
//    }
//
//    public void simulateUnstableService(String name, double failRate) {
//        if (Math.random() < failRate) {
//            throw new RuntimeException(name + " failed randomly");
//        }
//    }
//}
