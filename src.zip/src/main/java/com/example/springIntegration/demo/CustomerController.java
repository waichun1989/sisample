//package com.example.springIntegration.demo;
//
//import com.example.springIntegration.demo.supporting.Customer;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.http.ResponseEntity;
//import org.springframework.integration.support.MessageBuilder;
//import org.springframework.messaging.MessageChannel;
//import org.springframework.web.bind.annotation.PostMapping;
//import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.web.bind.annotation.RestController;
//
//@RestController
//public class CustomerController {
//    @Autowired
//    private MessageChannel customerInputChannel;
//
//    @PostMapping("/onboard")
//    public ResponseEntity<?> onboard(@RequestBody Customer customer) {
//        customerInputChannel.send(MessageBuilder.withPayload(customer).build());
//        return ResponseEntity.ok("Accepted");
//    }
//}