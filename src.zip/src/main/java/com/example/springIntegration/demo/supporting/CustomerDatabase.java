package com.example.springIntegration.demo.supporting;

public class CustomerDatabase {
    public static void save(Customer customer) {
        // Mock database save
        System.out.println("Saving customer: " + customer);
    }
}
