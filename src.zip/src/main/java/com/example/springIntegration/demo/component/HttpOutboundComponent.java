package com.example.springIntegration.demo.component;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.integration.channel.DirectChannel;
import org.springframework.integration.dsl.IntegrationFlow;
import org.springframework.integration.http.dsl.Http;
import org.springframework.messaging.MessageChannel;

@Configuration
public class HttpOutboundComponent {

    @Bean
    public MessageChannel httpOutboundInput() {
        return new DirectChannel();
    }

    @Bean
    public IntegrationFlow httpOutboundFlow() {
        return IntegrationFlow
                .from(httpOutboundInput())
                .handle(Http.outboundGateway("https://webhook.site/55e8f8c3-dc33-4e05-a211-f11bd7f32d0d")
                        .httpMethod(HttpMethod.POST)
                        .expectedResponseType(String.class) // this is for the body type
                        .extractResponseBody(false))
                .handle((payload, headers) -> {
                    // payload here is the response body from webhook.site
                    System.out.println("Webhook response: " + payload);

                    if (payload instanceof ResponseEntity) {
                        ResponseEntity<?> response = (ResponseEntity<?>) payload;

                        // You now have access to:
                        System.out.println("Status Code: " + response.getStatusCode());
                        System.out.println("Headers: " + response.getHeaders());
                        System.out.println("Body: " + response.getBody());

                        return response; // This will return full ResponseEntity to the HTTP client
                    }

                    // Fallback
                    return payload; // return to original HTTP client
                })
                .get();
    }
}
