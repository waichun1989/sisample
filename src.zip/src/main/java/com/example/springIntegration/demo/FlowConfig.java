package com.example.springIntegration.demo;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Component
@ConfigurationProperties(prefix = "integration")
public class FlowConfig {

    private List<Map<String, String>> flow;

    public List<Map<String, String>> getFlow() {
        return flow;
    }

    public void setFlow(List<Map<String, String>> flow) {
        this.flow = flow;
    }
}
