package com.example.springIntegration.demo.supporting;

public class CustomerValidator {
    public static void validate(Customer customer) {
        if (customer.name == null || customer.email == null) {
            throw new IllegalArgumentException("Invalid customer data");
        }
    }
}
