package com.example.springIntegration.demo.supporting;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Customer {
    public String name;
    public String email;
    public boolean vip;

    public Customer() {}
    public Customer(String name, String email, boolean vip) {
        this.name = name;
        this.email = email;
        this.vip = vip;
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder("Customer {\n");
        sb.append("  name: '").append(name).append("',\n");
        sb.append("  email: '").append(email).append("',\n");
        sb.append("  vip: ").append(vip).append("\n");
        sb.append("}");
        return sb.toString();
    }
}
